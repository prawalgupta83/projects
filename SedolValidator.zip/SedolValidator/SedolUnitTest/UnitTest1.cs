﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SedolValidator;
using System;

namespace SedolUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
           
            SedolClass sedolClass = new SedolClass();
            ISedolValidationResult result = sedolClass.ValidateSedol("Null");

            TestSedolValidator testSedolValidator = new TestSedolValidator();

            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);

        }
        [TestMethod]
        public void TestMethod2()
        {

            SedolClass sedolClass = new SedolClass();
            ISedolValidationResult result = sedolClass.ValidateSedol("");

            TestSedolValidator testSedolValidator = new TestSedolValidator();

            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);

        }
    }
}
