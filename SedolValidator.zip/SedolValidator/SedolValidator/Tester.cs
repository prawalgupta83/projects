﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SedolValidator
{
    public class Tester
    {
        public void TestSedolValidator(TestSedolValidator testSedolValidator)
        {
            SedolClass sedolClass = new SedolClass();            

            ISedolValidationResult result = sedolClass.ValidateSedol("Null");

            testSedolValidator = new TestSedolValidator();
          
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);


            ISedolValidationResult result1 = sedolClass.ValidateSedol("");
          
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);
         
            ISedolValidationResult result2 = sedolClass.ValidateSedol("12");
          
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);
        

            ISedolValidationResult result3 = sedolClass.ValidateSedol("123456789");
         
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);
          

            ISedolValidationResult result4 = sedolClass.ValidateSedol("1234567");
           
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);
           

            ISedolValidationResult result5 = sedolClass.ValidateSedol("0709954");
            
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result6 = sedolClass.ValidateSedol("B0YBKJ7");
            testSedolValidator = new TestSedolValidator();
        
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result11 = sedolClass.ValidateSedol("9123451");
           
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result12 = sedolClass.ValidateSedol("9ABCDE8");
            
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result7 = sedolClass.ValidateSedol("9123_51");
           
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result8 = sedolClass.ValidateSedol("VA.CDE8");
            
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);

            ISedolValidationResult result9 = sedolClass.ValidateSedol("9123458");
            
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);
            
            ISedolValidationResult result10 = sedolClass.ValidateSedol("9ABCDE1");
          
            testSedolValidator = new TestSedolValidator();
            Console.WriteLine(testSedolValidator.InputString + "|" + testSedolValidator.IsValidSedol + "|" + testSedolValidator.IsUserDefined  + "|" + testSedolValidator.ValidationDetails);

            Console.ReadLine();
            //return result;
        }
    }

}
