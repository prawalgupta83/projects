﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SedolValidator
{
    public class SedolClass:ISedolValidator
    {
        public ISedolValidationResult ValidateSedol(string input)
        {
            ISedolValidationResult sedolValidationResult=null;

            TestSedolValidator.inputString = input;
            int length = input.Length;
            if (length > 7 || length < 7)
            {
                TestSedolValidator.validationDetails = "Input string was not 7-characters long";
                return null;
            }
            // Creating array of string length  
            char[] ch = new char[length];
           
            // Copy character by character into array  
            for (int i = 0; i < length; i++)
            {
                ch[i] = input[i];
                //Check if charactor is 9 or not
                if (i == 0)
                {
                    if (ch[i].ToString() != "9")
                    {
                        TestSedolValidator.isUserDefined = false;
                    }
                    else
                    {
                        TestSedolValidator.isUserDefined = true;
                    }
                }
            }

            int totalChecksum = 0;
            int lastDigit = 0;
            //checksum
            bool invalidString = false;
            for(int i=0;i< ch.Length;i++)
            {
                if (!Char.IsLetter(ch[i]))
                {
                    if (ch[i].ToString() == "." || ch[i].ToString() == "_")//check only for . and _ characters only as per examples
                    {
                        TestSedolValidator.validationDetails = "SEDOL contains invalid characters";
                        TestSedolValidator.isUserDefined = false;
                        invalidString = true;
                        break;
                    }
                    if (i == 0)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 1;
                    }
                    if (i == 1)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 3;
                    }
                    if (i == 2)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 1;
                    }
                    if (i == 3)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 7;
                    }
                    if (i == 4)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 3;
                    }
                    if (i == 5)
                    {
                        totalChecksum += int.Parse(ch[i].ToString()) * 9;
                    }
                    if (i == 6)
                    {
                        lastDigit = int.Parse(ch[i].ToString());
                    }
                }
                else
                {
                    if (i < 6)
                    {
                        int index = char.ToUpper(ch[i]) - 64;
                        totalChecksum += (9 + index);
                    }
                    if (i == 6)
                    {
                        int index = char.ToUpper(ch[i]) - 64;
                        lastDigit = (9 + index);
                    }
                   
                }
            }
            //check digit
            var mod = (10 - (totalChecksum % 10)) % 10;
            Console.WriteLine("Checksum: "+ mod);
            
            if (!invalidString)
            {
                //check for valid sedol
                if ((totalChecksum + lastDigit) % 10 == 0)
                {
                    TestSedolValidator.isValidSedol = true;
                    TestSedolValidator.validationDetails = "Null";
                }
                else
                {
                    TestSedolValidator.isValidSedol = false;
                    TestSedolValidator.validationDetails = "Checksum digit does not agree with the rest of the input";
                }
            }

            return sedolValidationResult;
        }

        
    }
}
