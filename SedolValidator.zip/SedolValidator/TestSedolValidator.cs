﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SedolValidator
{
    public class TestSedolValidator:ISedolValidationResult
    {
        public static string inputString;
        public static bool isValidSedol;
        public static bool isUserDefined;
        public static string validationDetails;

        private string _inputString;
        public string InputString  // read-only instance property
        {
            get => _inputString;
        }

        private bool _isValidSedol;
        public bool IsValidSedol  // read-only instance property
        {
            get => _isValidSedol;
        }

        private bool _isUserDefined;
        public bool IsUserDefined  // read-only instance property
        {
            get => _isUserDefined;
        }

        private string _validationDetails;
        public string ValidationDetails  // read-only instance property
        {
            get => _validationDetails;
        }

        // constructor
        public TestSedolValidator()
        {
            _isValidSedol = isValidSedol;
            _validationDetails = validationDetails;
            _isUserDefined = isUserDefined;
            _inputString = inputString;
        }
    }
}
